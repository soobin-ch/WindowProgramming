﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SImpleCalculator
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoBtn2.Checked)
            {
                txtBtn2.Focus();
                txtBtn2.Enabled = true;
                txtBtn1.Enabled = false;
            }
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            if (txtBtn1.Enabled)
                txtBtn1.Text += btn1.Text;
            else
                txtBtn2.Text += btn1.Text;
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            if (txtBtn1.Enabled)
                txtBtn1.Text += btn2.Text;
            else
                txtBtn2.Text += btn2.Text; ;
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            if (txtBtn1.Enabled)
                txtBtn1.Text += btn3.Text;
            else
                txtBtn2.Text += btn3.Text;
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            if (txtBtn1.Enabled)
                txtBtn1.Text += btn4.Text;
            else
                txtBtn2.Text += btn4.Text;
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            if (txtBtn1.Enabled)
                txtBtn1.Text += btn5.Text;
            else
                txtBtn2.Text += btn5.Text;
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            if (txtBtn1.Enabled)
                txtBtn1.Text += btn6.Text;
            else
                txtBtn2.Text += btn6.Text;
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            if (txtBtn1.Enabled)
                txtBtn1.Text += btn7.Text;
            else
                txtBtn2.Text += btn7.Text;
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            if (txtBtn1.Enabled)
                txtBtn1.Text += btn8.Text;
            else
                txtBtn2.Text += btn8.Text;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            rdoBtn1.Checked = true;
            txtBtn1.Focus();
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            if (txtBtn1.Enabled)
                txtBtn1.Text += btn9.Text;
            else
                txtBtn2.Text += btn9.Text;
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            if (txtBtn1.Enabled)
                txtBtn1.Text += btn0.Text;
            else
                txtBtn2.Text += btn0.Text;
        }

        private void btnPnt_Click(object sender, EventArgs e)
        {
            if (txtBtn1.Enabled)
                txtBtn1.Text += btnPnt.Text;
            else
                txtBtn2.Text += btnPnt.Text;
        }

        private void rdoBtn1_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoBtn1.Checked)
            {
                txtBtn1.Focus();
                txtBtn1.Enabled = true;
                txtBtn2.Enabled = false;
            }
        }

        private void btnChg_Click(object sender, EventArgs e)
        {
          
            
            if (txtBtn1.Enabled)
            {

                double chgNum1 = double.Parse(txtBtn1.Text);
                if (chgNum1 > 0 || chgNum1 <= 0)
                    chgNum1 = -chgNum1;

                txtBtn1.Text = chgNum1.ToString();

            }
            else if (txtBtn2.Enabled)
            {
                double chgNum2 = double.Parse(txtBtn2.Text);
                if (chgNum2 > 0 || chgNum2 <= 0)
                    chgNum2 = -chgNum2;

                txtBtn2.Text = chgNum2.ToString();
            }
        }

        private void btnsqrt_Click(object sender, EventArgs e)
        {
            


            if (txtBtn1.Enabled)
            {
                double txtNum1 = double.Parse(txtBtn1.Text);
                if (txtNum1 < 0)
                {
                    txtBtn1.Text = "0";
                }
                else {
                    double sqrtNum1 = Math.Sqrt(txtNum1);
                    txtBtn1.Text = sqrtNum1.ToString();
                        }

            } else
            {
                double txtNum2 = double.Parse(txtBtn2.Text);
                if(txtNum2 < 0)
                {
                    txtBtn2.Text = "0";
                }else
                {
                    double sqrtNum2 = Math.Sqrt(txtNum2);
                    txtBtn2.Text = sqrtNum2.ToString();
                }
            }  
            
           
         }

        private void btnreciprocal_Click(object sender, EventArgs e)
        {
            if(txtBtn1.Enabled)
            {
                double txtNum1 = double.Parse(txtBtn1.Text);

                if (txtNum1 == 0)
                    txtBtn1.Text = "0";
                else
                {
                    double rcip1 = 1 / txtNum1;
                    txtBtn1.Text = rcip1.ToString();
                }
            }else
            {
                double txtNum2 = double.Parse(txtBtn2.Text);
                if (txtNum2 == 0)
                    txtBtn2.Text = "0";
                else
                {
                    double rcip2 = 1 / txtNum2;
                    txtBtn2.Text = rcip2.ToString();
                }
            }
        }

        private void btnLastTextRm_Click(object sender, EventArgs e)
        {
            if(txtBtn1.Enabled)
            {
                if (txtBtn1.Text.Length > 0)
                {
                    txtBtn1.Text = txtBtn1.Text.Substring(0, txtBtn1.Text.Length - 1);
                }
            }else
            {
                if(txtBtn2.Text.Length >0)
                {
                    txtBtn2.Text = txtBtn2.Text.Substring(0, txtBtn2.Text.Length - 1);
                }
             }
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            lblOpr.Text = "+";
        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            lblOpr.Text = "-";
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            lblOpr.Text = "*";
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            lblOpr.Text = "/";
        }

        private void btnModulo_Click(object sender, EventArgs e)
        {
            lblOpr.Text = "%";
        }

        private void btnResult_Click(object sender, EventArgs e)
        {
            double txtNum1 = double.Parse(txtBtn1.Text);
            double txtNum2 = double.Parse(txtBtn2.Text);
            double rst = 0;

           



            if (lblOpr.Text == "+" || lblOpr.Text == "")
                rst = txtNum1 + txtNum2;
            else if (lblOpr.Text == "-")
                rst = txtNum1 - txtNum2;
            else if (lblOpr.Text == "*")
                rst = txtNum1 * txtNum2;
            else if (lblOpr.Text == "/")
                rst = txtNum1 / txtNum2;
            else if( lblOpr.Text =="%")
                rst = txtNum1 % txtNum2;
           


            if(lblOpr.Text != "")
                lblResult.Text = txtBtn1.Text + lblOpr.Text + txtBtn2.Text + "=" + rst.ToString();
            else
                lblResult.Text = txtBtn1.Text + "+" + txtBtn2.Text + "=" + rst.ToString();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtBtn1.Clear();
            txtBtn2.Clear();
            lblOpr.Text = "";
            lblResult.Text = "";
        }
    }
}
