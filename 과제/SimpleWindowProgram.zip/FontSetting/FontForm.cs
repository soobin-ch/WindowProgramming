﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FontSetting
{
    public partial class FontForm: Form
    {
        public FontForm()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void FontForm_Load(object sender, EventArgs e)
        {
            InstalledFontCollection ifc = new InstalledFontCollection();

            for(int j = 0; j<ifc.Families.Length; ++j)
            {
                cboFonts.Items.Add(ifc.Families[j].Name);
            }
            cboFonts.SelectedIndex = 0;
        }

        private void chkBold_CheckedChanged(object sender, EventArgs e)
        {
            txtInput.Font = new Font(txtInput.Font, txtInput.Font.Style ^ FontStyle.Bold);
        }

        private void chkUnderline_CheckedChanged(object sender, EventArgs e)
        {
            txtInput.Font = new Font(txtInput.Font, txtInput.Font.Style ^ FontStyle.Underline);
        }

        private void chkItalic_CheckedChanged(object sender, EventArgs e)
        {
            txtInput.Font = new Font(txtInput.Font, txtInput.Font.Style ^ FontStyle.Italic);
        }

        private void chkStrikeout_CheckedChanged(object sender, EventArgs e)
        {
            txtInput.Font = new Font(txtInput.Font, txtInput.Font.Style ^ FontStyle.Strikeout);
        }

        private void rdoRed_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoRed.Checked) txtInput.ForeColor = Color.Red;
        }

        private void rdoOrange_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoRed.Checked) txtInput.ForeColor = Color.Orange;
        }

        private void rdoYellow_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoRed.Checked) txtInput.ForeColor = Color.Yellow;
        }

        private void rdoGreen_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoRed.Checked) txtInput.ForeColor = Color.Green;
        }

        private void rdoBlue_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoRed.Checked) txtInput.ForeColor = Color.Blue;
        }

        private void rdoNavy_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoRed.Checked) txtInput.ForeColor = Color.Navy;
        }

        private void rdoViolet_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoRed.Checked) txtInput.ForeColor = Color.Violet;
        }

        private void rdoBlack_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoRed.Checked) txtInput.ForeColor = Color.Black;
        }

        private void nudFontSize_ValueChanged(object sender, EventArgs e)
        {
            txtInput.Font = new Font(txtInput.Font.FontFamily, float.Parse(nudFontSize.Value.ToString()),txtInput.Font.Style);
        }

        private void cboFonts_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtInput.Font = new Font(cboFonts.SelectedItem.ToString(),
                float.Parse(nudFontSize.Value.ToString()), txtInput.Font.Style);
        }
    }
}
