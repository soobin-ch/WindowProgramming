﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigitalWatch
{
    public partial class WatchForm: Form
    {
        public WatchForm()
        {
            InitializeComponent();
        }

        private void btnToggle_Click(object sender, EventArgs e)
        {
            if (btnToggle.Text == "Start") btnToggle.Text = "Stop";
            else btnToggle.Text = "Start";


            myTimer.Enabled = !myTimer.Enabled;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void myTimer_Tick(object sender, EventArgs e)
        {
            lblResult.Text = DateTime.Now.ToString("tt hh:mm:ss");
        }
    }
}
