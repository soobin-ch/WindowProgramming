﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StopWatch1
{
    public partial class StopWatchForm: Form
    {
        DateTime startTime;
        TimeSpan timeElapsed;

        public StopWatchForm()
        {
            InitializeComponent();
        }

        private void btnToggle_Click(object sender, EventArgs e)
        {
            if (btnToggle.Text == "Start")
            {

                btnToggle.Text = "Stop";


                myTimer.Enabled = !myTimer.Enabled;
                timeElapsed = TimeSpan.Zero;

                startTime = DateTime.Now;

            }else
            {
                myTimer.Stop();
                timeElapsed = DateTime.Now - startTime;
                lblResult.Text= $"{timeElapsed:hh\\:mm\\:ss}.{(int)(timeElapsed.Milliseconds / 10)}";
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void myTimer_Tick(object sender, EventArgs e)
        {
            timeElapsed = DateTime.Now - startTime;  // 경과 시간 계산
                                                     // 경과 시간을 라벨에 표시 (예: "00:00:01" 형태로)
            lblResult.Text = $"{timeElapsed:hh\\:mm\\:ss}.{(int)(timeElapsed.Milliseconds / 10)}";
        }

        private void StopWatchForm_Load(object sender, EventArgs e)
        {

        }
    }
}
