﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyCalculator
{
    public partial class CalcForm: Form
    {
        public CalcForm()
        {
            InitializeComponent();
        }

        private void cboOp_Load(object sender, EventArgs e)
        {
            cboOp.SelectedIndex = 0;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtNum1.Text = txtNum2.Text = lblResult.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            double num1, num2, result;

            try
            {
                num1 = double.Parse(txtNum1.Text);
                num2 = Convert.ToDouble(txtNum2.Text);

                switch (cboOp.SelectedItem.ToString())
                {
                    case "+":
                        result = num1 + num2;
                        break;
                    case "-":
                        result = num1 - num2;
                        break;
                    case "*":
                        result = num1 * num2;
                        break;
                    default:
                        result = num1 / num2;
                        break;
                  

                }
                lblResult.Text = result.ToString();

            }
            catch(Exception ex)
            {
                lblResult.Text = ex.Message;
            }
            txtNum1.SelectAll();
            txtNum1.Focus();
        }
    }
}
