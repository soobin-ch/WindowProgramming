﻿namespace RGB_Color
{
    partial class MainForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRedPanel = new System.Windows.Forms.Label();
            this.lblGreenPanel = new System.Windows.Forms.Label();
            this.lblBluePanel = new System.Windows.Forms.Label();
            this.hsbRed = new System.Windows.Forms.HScrollBar();
            this.hsbBlue = new System.Windows.Forms.HScrollBar();
            this.hsbGreen = new System.Windows.Forms.HScrollBar();
            this.lblRed = new System.Windows.Forms.Label();
            this.lblGreen = new System.Windows.Forms.Label();
            this.lblBlue = new System.Windows.Forms.Label();
            this.lblResultPanel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblRedPanel
            // 
            this.lblRedPanel.BackColor = System.Drawing.Color.Red;
            this.lblRedPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRedPanel.ForeColor = System.Drawing.SystemColors.Control;
            this.lblRedPanel.Location = new System.Drawing.Point(80, 33);
            this.lblRedPanel.Name = "lblRedPanel";
            this.lblRedPanel.Padding = new System.Windows.Forms.Padding(30);
            this.lblRedPanel.Size = new System.Drawing.Size(100, 100);
            this.lblRedPanel.TabIndex = 0;
            this.lblRedPanel.Text = "Red";
            this.lblRedPanel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGreenPanel
            // 
            this.lblGreenPanel.BackColor = System.Drawing.Color.Green;
            this.lblGreenPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblGreenPanel.ForeColor = System.Drawing.SystemColors.Control;
            this.lblGreenPanel.Location = new System.Drawing.Point(191, 33);
            this.lblGreenPanel.Name = "lblGreenPanel";
            this.lblGreenPanel.Padding = new System.Windows.Forms.Padding(30);
            this.lblGreenPanel.Size = new System.Drawing.Size(100, 100);
            this.lblGreenPanel.TabIndex = 1;
            this.lblGreenPanel.Text = "Green";
            this.lblGreenPanel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBluePanel
            // 
            this.lblBluePanel.AutoEllipsis = true;
            this.lblBluePanel.BackColor = System.Drawing.Color.Blue;
            this.lblBluePanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblBluePanel.ForeColor = System.Drawing.SystemColors.Control;
            this.lblBluePanel.Location = new System.Drawing.Point(311, 33);
            this.lblBluePanel.Name = "lblBluePanel";
            this.lblBluePanel.Padding = new System.Windows.Forms.Padding(30);
            this.lblBluePanel.Size = new System.Drawing.Size(100, 100);
            this.lblBluePanel.TabIndex = 2;
            this.lblBluePanel.Text = "Blue";
            // 
            // hsbRed
            // 
            this.hsbRed.Location = new System.Drawing.Point(82, 142);
            this.hsbRed.Maximum = 255;
            this.hsbRed.Name = "hsbRed";
            this.hsbRed.Size = new System.Drawing.Size(100, 16);
            this.hsbRed.TabIndex = 3;
            this.hsbRed.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hsbRed_Scroll);
            // 
            // hsbBlue
            // 
            this.hsbBlue.Location = new System.Drawing.Point(313, 142);
            this.hsbBlue.Maximum = 255;
            this.hsbBlue.Name = "hsbBlue";
            this.hsbBlue.Size = new System.Drawing.Size(100, 16);
            this.hsbBlue.TabIndex = 4;
            this.hsbBlue.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hsbBlue_Scroll);
            // 
            // hsbGreen
            // 
            this.hsbGreen.Location = new System.Drawing.Point(200, 142);
            this.hsbGreen.Maximum = 255;
            this.hsbGreen.Name = "hsbGreen";
            this.hsbGreen.Size = new System.Drawing.Size(100, 16);
            this.hsbGreen.TabIndex = 5;
            this.hsbGreen.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hsbGreen_Scroll);
            // 
            // lblRed
            // 
            this.lblRed.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblRed.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRed.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblRed.Location = new System.Drawing.Point(80, 173);
            this.lblRed.Name = "lblRed";
            this.lblRed.Size = new System.Drawing.Size(100, 25);
            this.lblRed.TabIndex = 6;
            this.lblRed.Text = "0";
            this.lblRed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGreen
            // 
            this.lblGreen.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblGreen.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblGreen.Enabled = false;
            this.lblGreen.Location = new System.Drawing.Point(201, 173);
            this.lblGreen.Name = "lblGreen";
            this.lblGreen.Size = new System.Drawing.Size(100, 25);
            this.lblGreen.TabIndex = 7;
            this.lblGreen.Text = "0";
            this.lblGreen.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBlue
            // 
            this.lblBlue.AccessibleRole = System.Windows.Forms.AccessibleRole.SplitButton;
            this.lblBlue.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblBlue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblBlue.Location = new System.Drawing.Point(315, 173);
            this.lblBlue.Name = "lblBlue";
            this.lblBlue.Size = new System.Drawing.Size(100, 25);
            this.lblBlue.TabIndex = 8;
            this.lblBlue.Text = "0";
            this.lblBlue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblResultPanel
            // 
            this.lblResultPanel.BackColor = System.Drawing.SystemColors.ControlText;
            this.lblResultPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblResultPanel.ForeColor = System.Drawing.SystemColors.Control;
            this.lblResultPanel.Location = new System.Drawing.Point(80, 235);
            this.lblResultPanel.Name = "lblResultPanel";
            this.lblResultPanel.Size = new System.Drawing.Size(314, 113);
            this.lblResultPanel.TabIndex = 9;
            this.lblResultPanel.Text = "Result";
            this.lblResultPanel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblResultPanel);
            this.Controls.Add(this.lblBlue);
            this.Controls.Add(this.lblGreen);
            this.Controls.Add(this.lblRed);
            this.Controls.Add(this.hsbGreen);
            this.Controls.Add(this.hsbBlue);
            this.Controls.Add(this.hsbRed);
            this.Controls.Add(this.lblBluePanel);
            this.Controls.Add(this.lblGreenPanel);
            this.Controls.Add(this.lblRedPanel);
            this.Name = "MainForm";
            this.Text = "RGB 색상표";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblRedPanel;
        private System.Windows.Forms.Label lblGreenPanel;
        private System.Windows.Forms.Label lblBluePanel;
        private System.Windows.Forms.HScrollBar hsbRed;
        private System.Windows.Forms.HScrollBar hsbBlue;
        private System.Windows.Forms.HScrollBar hsbGreen;
        private System.Windows.Forms.Label lblRed;
        private System.Windows.Forms.Label lblGreen;
        private System.Windows.Forms.Label lblBlue;
        private System.Windows.Forms.Label lblResultPanel;
    }
}

