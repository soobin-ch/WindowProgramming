﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorEng
{
    public partial class Form1: Form
    {
        bool fOp = false;
        string strOpType = "";
        bool fResult = false;

        double dNum1 = 0.0, dNum2 = 0.0, dResult = 0.0;
        int iNum1 = 0, iNum2 = 0, iResult = 0;

        private void btnResult_Click(object sender, EventArgs e)
        {
            fResult = true;

            if(IsNumeric(lblResult.Text, out dNum2, out iNum2))
            {
                switch(strOpType)
                {
                    case "+":
                        if (iBase == 10) dResult = dNum1 + dNum2;
                        else iResult = iNum1 + iNum2;
                        break;
                    case "-":
                        if (iBase == 10) dResult = dNum1 - dNum2;
                        else iResult = iNum1 - iNum2;
                        break;
                    case "*":
                        if (iBase == 10) dResult = dNum1 * dNum2;
                        else iResult = iNum1 - iNum2;
                        break;
                    case "/":
                        if (iBase == 10) dResult = dNum1 / dNum2;
                        else iResult = iNum1 / iNum2;

                        if(dNum2 !=0.0)
                        {
                            dResult = dNum1 / dNum2;
                        }else
                        {
                            MessageBox.Show("0으로 나눌 수 없습니다.");
                            fOp = true;
                            fResult = false;
                            return;
                        }
                            break;
                    case "%":
                        if (iBase == 10) dResult = dNum1 % dNum2;
                        else iResult = iNum1 % iNum2;

                        if (dNum2 != 0.0)
                        {
                            dResult = dNum1 % dNum2;
                        }
                        else
                        {
                            MessageBox.Show("0으로 나눌 수 없습니다.");
                            fOp = true;
                            fResult = false;
                            return;
                        }
                        break;

                    case "Mod":
                        iResult = iNum1 % iNum2;
                        if (iBase == 10) dResult = (double)iResult;
                        break;
                    case "And":
                        iResult = iNum1 & iNum2;
                        if (iBase == 10) dResult = (double)iResult;
                        break;
                    case "x^y":
                        dResult = Math.Pow(dNum1, dNum2);
                        if (iBase != 10) iResult = (int)dResult;
                        break;
                    case "Lsh":
                        iResult = iNum1 >> iNum2;
                        if (iBase == 10) dResult = (double)iResult;
                        break;
                    case "Or":
                        iResult = iNum1 | iNum2;
                        if (iBase == 10) dResult = (double)iResult;
                        break;
                    case "Xor":
                        iResult = iNum1 ^ iNum2;
                        if (iBase == 10) dResult = (double)iResult;
                        break;

                }

                if (iBase == 10) lblResult.Text = dResult.ToString();
                else lblResult.Text = Convert.ToString(iResult, iBase);
            }
        }

        private void btnBS_Click(object sender, EventArgs e)
        {
            if (lblResult.Text.Length == 1)
                lblResult.Text = "0";
            else
                lblResult.Text = lblResult.Text.Substring(0, lblResult.Text.Length - 1);
        }

        private void btnCE_Click(object sender, EventArgs e)
        {
            lblResult.Text = "0";
        }

        private void btnC_Click(object sender, EventArgs e)
        {
            lblResult.Text = "0";
            dNum1 = dNum2 = dResult = 0;
            fOp = false;
            strOpType = "";
            fResult = false;
        }

        private void rdoDec_CheckedChanged(object sender, EventArgs e)
        {
            if(IsNumeric(lblResult.Text, out dNum1, out iNum1)) {
                fOp = fResult = true;
                iBase = 10;

                lblResult.Text = Convert.ToString(iNum1, iBase);

                btn2.Enabled = true;
                btn3.Enabled = true;
                btn4.Enabled = true;
                btn5.Enabled = true;
                btn6.Enabled = true;
                btn7.Enabled = true;
                btn8.Enabled = true;
                btn9.Enabled = true;
                btnA.Enabled = false;
                btnB.Enabled = false;
                btnC.Enabled = false;
                btnD.Enabled = false;
                btnE.Enabled = false;
                btnF.Enabled = false;
                btnPoint.Enabled = true;
                groupBox2.Enabled = true;
                btnSin.Enabled = true;
                btnCos.Enabled = true;
                btnTan.Enabled = true;
                btnLn.Enabled = true;
                btnLog.Enabled = true;
                btnXY.Enabled = true;
                btnX3.Enabled = true;
                btnX2.Enabled = true;
                btnNFact.Enabled = true;
                btnXInv.Enabled = true;

            }
        }

    

        private void btnHex_CheckedChanged(object sender, EventArgs e)
        {
            if(IsNumeric(lblResult.Text, out dNum1, out iNum1))
            {
                fOp = fResult = true;
                iBase = 16;

                lblResult.Text = Convert.ToString(iNum1, iBase);
                btn2.Enabled = true;
                btn3.Enabled = true;
                btn4.Enabled = true;
                btn5.Enabled = true;
                btn6.Enabled = true;
                btn7.Enabled = true;
                btn8.Enabled = true;
                btn9.Enabled = true;
                btnA.Enabled = true;
                btnB.Enabled = true;
                btnC.Enabled = true;
                btnD.Enabled = true;
                btnE.Enabled = true;
                btnF.Enabled = true;

                btnPoint.Enabled = false;
                groupBox2.Enabled = false;
                btnSin.Enabled = false;
                btnCos.Enabled = false;
                btnTan.Enabled = false;
                btnLn.Enabled = false;
                btnLog.Enabled = false;
                btnXY.Enabled = false;
                btnX3.Enabled = false;
                btnX2.Enabled = false;
                btnNFact.Enabled = false;
                btnXInv.Enabled = false;

            }
        }

        private void btnOct_CheckedChanged(object sender, EventArgs e)
        {
            if (IsNumeric(lblResult.Text, out dNum1, out iNum1))
            {
                fOp = fResult = true;
                iBase = 8;

                lblResult.Text = Convert.ToString(iNum1, iBase);
                btn2.Enabled = true;
                btn3.Enabled = true;
                btn4.Enabled = true;
                btn5.Enabled = true;
                btn6.Enabled = true;
                btn7.Enabled = true;
                btn8.Enabled = false;
                btn9.Enabled = false;
                btnA.Enabled = false;
                btnB.Enabled = false;
                btnC.Enabled = false;
                btnD.Enabled = false;
                btnE.Enabled = false;
                btnF.Enabled = false;

                btnPoint.Enabled = false;
                groupBox2.Enabled = false;
                btnSin.Enabled = false;
                btnCos.Enabled = false;
                btnTan.Enabled = false;
                btnLn.Enabled = false;
                btnLog.Enabled = false;
                btnXY.Enabled = false;
                btnX3.Enabled = false;
                btnX2.Enabled = false;
                btnNFact.Enabled = false;
                btnXInv.Enabled = false;

            }
        }

        private void btnBin_CheckedChanged(object sender, EventArgs e)
        {
            if (IsNumeric(lblResult.Text, out dNum1, out iNum1))
            {
                fOp = fResult = true;
                iBase = 2;

                lblResult.Text = Convert.ToString(iNum1, iBase);
                btn2.Enabled = false;
                btn3.Enabled = false;
                btn4.Enabled = false;
                btn5.Enabled = false;
                btn6.Enabled = false;
                btn7.Enabled = false;
                btn8.Enabled = false;
                btn9.Enabled = false;
                btnA.Enabled = false;
                btnB.Enabled = false;
                btnC.Enabled = false;
                btnD.Enabled = false;
                btnE.Enabled = false;
                btnF.Enabled = false;

                btnPoint.Enabled = false;
                groupBox2.Enabled = false;
                btnSin.Enabled = false;
                btnCos.Enabled = false;
                btnTan.Enabled = false;
                btnLn.Enabled = false;
                btnLog.Enabled = false;
                btnXY.Enabled = false;
                btnX3.Enabled = false;
                btnX2.Enabled = false;
                btnNFact.Enabled = false;
                btnXInv.Enabled = false;

            }
        }

        private void btnNot_Click(object sender, EventArgs e)
        {
            if(IsNumeric(lblResult.Text, out dNum2, out iNum2))
            {
                iResult = ~iNum2;
                lblResult.Text = Convert.ToString(iResult, iBase);
            }
        }

        private void btnInt_Click(object sender, EventArgs e)
        {
            lblResult.Text = ((int)double.Parse(lblResult.Text)).ToString();
        }

        private void btnX3_Click(object sender, EventArgs e)
        {
            lblResult.Text = Math.Pow(double.Parse(lblResult.Text), 3).ToString();

        }

        private void btnX2_Click(object sender, EventArgs e)
        {
            lblResult.Text = (double.Parse(lblResult.Text) * double.Parse(lblResult.Text)).ToString();
        }

        private void btnXInv_Click(object sender, EventArgs e)
        {
            if (lblResult.Text != "0") lblResult.Text = (1.0 / double.Parse(lblResult.Text)).ToString();
            else
            {
                MessageBox.Show("0의 역수는 없습니다.");
                return;
            }
        }

        private void btnNFact_Click(object sender, EventArgs e)
        {
            try
            {
                double dFact = 1.0;
                for (int iNum = int.Parse(lblResult.Text); iNum > 1; iNum--)
                    dFact *= iNum;
                lblResult.Text = dFact.ToString();
            }catch
            {
                MessageBox.Show("Factorial은 정수에만 적용됩니다!");
            }
        }

        private void btnSin_Click(object sender, EventArgs e)
        {
            dResult = double.Parse(lblResult.Text);

            if(chkInv.Checked)
            {
                dResult = Math.Asin(dResult);

                if (rdoModeDeg.Checked) dResult = 180.0 * dResult / Math.PI;
            }else
            {
                if (rdoModeDeg.Checked) dResult = dResult * Math.PI / 180.0;
                dResult = Math.Sin(dResult);

            }
            lblResult.Text = dResult.ToString();

        }

        private void btnLog_Click(object sender, EventArgs e)
        {
            dResult = double.Parse(lblResult.Text);
            if(chkInv.Checked)
            {
                dResult = Math.Log(10, dResult);

            }else
            {
                dResult = Math.Log10(dResult);
            }
            lblResult.Text = dResult.ToString();
        }

        private void btnLn_Click(object sender, EventArgs e)
        {
            dResult = double.Parse(lblResult.Text);
            if(chkInv.Checked)
            {
                dResult = Math.Pow(Math.E, dResult);
            }
            else
            {
                dResult = Math.Log(dResult);
            }
            lblResult.Text = dResult.ToString();
        }

        private void btnCos_Click(object sender, EventArgs e)
        {
            dResult = double.Parse(lblResult.Text);
            if (chkInv.Checked)
            {
                dResult = Math.Acos(dResult);
                // degree 각인 경우 변환
                if (rdoModeDeg.Checked) dResult = 180.0 * dResult / Math.PI;
            }
            else
            {
                // degree 각인 경우 radian으로 변환
                if (rdoModeDeg.Checked) dResult = dResult * Math.PI / 180.0;
                dResult = Math.Cos(dResult);
            }
            lblResult.Text = dResult.ToString();
        }

        private void btnTan_Click(object sender, EventArgs e)
        {
            dResult = double.Parse(lblResult.Text);
            if (chkInv.Checked)
            {
                dResult = Math.Atan(dResult);
                // degree 각인 경우 변환
                if (rdoModeDeg.Checked) dResult = 180.0 * dResult / Math.PI;
            }
            else
            {
                // degree 각인 경우 radian으로 변환
                if (rdoModeDeg.Checked) dResult = dResult * Math.PI / 180.0;
                dResult = Math.Tan(dResult);
            }
            lblResult.Text = dResult.ToString();
        }

        private void btnPoint_Click(object sender, EventArgs e)
        {
            if(fOp || fResult)
            {
                lblResult.Text = "0.";
                fOp = false;
                fResult = false;
            }else
            {
                string sValue = lblResult.Text + ".";
                if ((IsNumeric(sValue))) lblResult.Text = sValue;
            }
        }

        private void btnInfixOperator_Click(object sender, EventArgs e)
        {
            Button infixOp = (Button)sender;

            if(iBase == 10)
            {
                dNum1 = double.Parse(lblResult.Text);
                iNum1 = (int)dNum1;
            }else
            {
                iNum1 = Convert.ToInt32(lblResult.Text, iBase);
                dNum2 = (double)iNum1;
            }

            fOp = true;
            strOpType = infixOp.Text;
        }

        private void btnSign_Click(object sender, EventArgs e)
        {
            lblResult.Text = (double.Parse(lblResult.Text) * (-1)).ToString();
        }

        private void btnn_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            if(lblResult.Text == "0" || fOp == true || fResult == true)
            {
                lblResult.Text = btn.Text;
                fOp = false;
                fResult = false;

            }else
            {
                string sValue = lblResult.Text + btn.Text;
                if (IsNumeric(sValue)) lblResult.Text = sValue;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        int iBase = 10;
        public Form1()
        {
            InitializeComponent();
        }


        private bool IsNumeric(string strVal, out double dVal, out int iVal)
        {
            bool fResult = true;
            dVal = 0.0;
            iVal = 0;

            try
            {
                if (iBase == 10)
                {
                    dVal = double.Parse(strVal);
                    iVal = (int)dVal;
                }
                else
                {
                    iVal = Convert.ToInt32(strVal, iBase);
                    dVal = (double)iVal;
                }
            }
            catch
            {
                MessageBox.Show("입력한 문자열을 숫자로 변환할 수 없습니다.");
                fResult = false;
            }
            return fResult;
        }


        private bool IsNumeric(string strVal)
        {
            if (string.IsNullOrEmpty(strVal)) return false; // 빈 값이면 숫자 아님

            try
            {
                // 현재 사용 중인 진법(iBase)에 따라 유효성 검사
                switch (iBase)
                {
                    case 10: // 10진수: 정수 또는 실수 허용
                        double.Parse(strVal);
                        break;

                    case 16: // 16진수: 숫자(0~9) + 문자(A~F) 허용
                        Convert.ToInt32(strVal, 16);
                        break;

                    case 8: // 8진수: 숫자(0~7)만 허용
                        Convert.ToInt32(strVal, 8);
                        break;

                    case 2: // 2진수: 숫자(0,1)만 허용
                        Convert.ToInt32(strVal, 2);
                        break;

                    default:
                        return false; // 알 수 없는 진법이면 false 반환
                }

                return true; // 변환 성공하면 숫자로 판단
            }
            catch
            {
                return false; // 변환 실패하면 숫자가 아님
            }
        }
    }
}
