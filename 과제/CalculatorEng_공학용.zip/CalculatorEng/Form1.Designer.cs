﻿namespace CalculatorEng
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblResult = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnBin = new System.Windows.Forms.RadioButton();
            this.btnOct = new System.Windows.Forms.RadioButton();
            this.rdoDec = new System.Windows.Forms.RadioButton();
            this.btnHex = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chkInv = new System.Windows.Forms.CheckBox();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.rdoModeDeg = new System.Windows.Forms.RadioButton();
            this.btnBS = new System.Windows.Forms.Button();
            this.btnCE = new System.Windows.Forms.Button();
            this.btnCC = new System.Windows.Forms.Button();
            this.btnSin = new System.Windows.Forms.Button();
            this.btnXY = new System.Windows.Forms.Button();
            this.btnCos = new System.Windows.Forms.Button();
            this.btnX3 = new System.Windows.Forms.Button();
            this.btnTan = new System.Windows.Forms.Button();
            this.btnX2 = new System.Windows.Forms.Button();
            this.btnLog = new System.Windows.Forms.Button();
            this.btnNFact = new System.Windows.Forms.Button();
            this.btnLn = new System.Windows.Forms.Button();
            this.btnXInv = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btnNot = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btnInt = new System.Windows.Forms.Button();
            this.btnResult = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.btnPoint = new System.Windows.Forms.Button();
            this.btnSign = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btnF = new System.Windows.Forms.Button();
            this.btnE = new System.Windows.Forms.Button();
            this.btnD = new System.Windows.Forms.Button();
            this.btnB = new System.Windows.Forms.Button();
            this.btnA = new System.Windows.Forms.Button();
            this.btnC = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblResult
            // 
            this.lblResult.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblResult.Location = new System.Drawing.Point(85, 29);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(707, 35);
            this.lblResult.TabIndex = 0;
            this.lblResult.Text = "0";
            this.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnBin);
            this.groupBox1.Controls.Add(this.btnOct);
            this.groupBox1.Controls.Add(this.rdoDec);
            this.groupBox1.Controls.Add(this.btnHex);
            this.groupBox1.Location = new System.Drawing.Point(87, 76);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(351, 75);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // btnBin
            // 
            this.btnBin.Location = new System.Drawing.Point(238, 31);
            this.btnBin.Name = "btnBin";
            this.btnBin.Size = new System.Drawing.Size(69, 24);
            this.btnBin.TabIndex = 6;
            this.btnBin.Text = "Bin";
            this.btnBin.UseVisualStyleBackColor = true;
            this.btnBin.CheckedChanged += new System.EventHandler(this.btnBin_CheckedChanged);
            // 
            // btnOct
            // 
            this.btnOct.Location = new System.Drawing.Point(168, 32);
            this.btnOct.Name = "btnOct";
            this.btnOct.Size = new System.Drawing.Size(69, 24);
            this.btnOct.TabIndex = 5;
            this.btnOct.Text = "Oct";
            this.btnOct.UseVisualStyleBackColor = true;
            this.btnOct.CheckedChanged += new System.EventHandler(this.btnOct_CheckedChanged);
            // 
            // rdoDec
            // 
            this.rdoDec.Checked = true;
            this.rdoDec.Location = new System.Drawing.Point(93, 31);
            this.rdoDec.Name = "rdoDec";
            this.rdoDec.Size = new System.Drawing.Size(69, 24);
            this.rdoDec.TabIndex = 4;
            this.rdoDec.TabStop = true;
            this.rdoDec.Text = "Dec";
            this.rdoDec.UseVisualStyleBackColor = true;
            this.rdoDec.CheckedChanged += new System.EventHandler(this.rdoDec_CheckedChanged);
            // 
            // btnHex
            // 
            this.btnHex.Location = new System.Drawing.Point(7, 32);
            this.btnHex.Name = "btnHex";
            this.btnHex.Size = new System.Drawing.Size(69, 24);
            this.btnHex.TabIndex = 3;
            this.btnHex.Text = "Hex";
            this.btnHex.UseVisualStyleBackColor = true;
            this.btnHex.CheckedChanged += new System.EventHandler(this.btnHex_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.chkInv);
            this.groupBox2.Controls.Add(this.radioButton6);
            this.groupBox2.Controls.Add(this.rdoModeDeg);
            this.groupBox2.Location = new System.Drawing.Point(473, 76);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(319, 75);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            // 
            // chkInv
            // 
            this.chkInv.AutoSize = true;
            this.chkInv.Location = new System.Drawing.Point(195, 36);
            this.chkInv.Name = "chkInv";
            this.chkInv.Size = new System.Drawing.Size(43, 16);
            this.chkInv.TabIndex = 10;
            this.chkInv.Text = "Inv";
            this.chkInv.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.Checked = true;
            this.radioButton6.Location = new System.Drawing.Point(106, 31);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(82, 24);
            this.radioButton6.TabIndex = 8;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "Radians";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // rdoModeDeg
            // 
            this.rdoModeDeg.Location = new System.Drawing.Point(22, 32);
            this.rdoModeDeg.Name = "rdoModeDeg";
            this.rdoModeDeg.Size = new System.Drawing.Size(96, 24);
            this.rdoModeDeg.TabIndex = 7;
            this.rdoModeDeg.Text = "Degrees";
            this.rdoModeDeg.UseVisualStyleBackColor = true;
            // 
            // btnBS
            // 
            this.btnBS.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnBS.ForeColor = System.Drawing.Color.Red;
            this.btnBS.Location = new System.Drawing.Point(314, 167);
            this.btnBS.Name = "btnBS";
            this.btnBS.Size = new System.Drawing.Size(135, 43);
            this.btnBS.TabIndex = 3;
            this.btnBS.Text = "Backspace";
            this.btnBS.UseVisualStyleBackColor = true;
            this.btnBS.Click += new System.EventHandler(this.btnBS_Click);
            // 
            // btnCE
            // 
            this.btnCE.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnCE.ForeColor = System.Drawing.Color.Red;
            this.btnCE.Location = new System.Drawing.Point(473, 167);
            this.btnCE.Name = "btnCE";
            this.btnCE.Size = new System.Drawing.Size(123, 43);
            this.btnCE.TabIndex = 4;
            this.btnCE.Text = "CE";
            this.btnCE.UseVisualStyleBackColor = true;
            this.btnCE.Click += new System.EventHandler(this.btnCE_Click);
            // 
            // btnCC
            // 
            this.btnCC.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnCC.ForeColor = System.Drawing.Color.Red;
            this.btnCC.Location = new System.Drawing.Point(615, 167);
            this.btnCC.Name = "btnCC";
            this.btnCC.Size = new System.Drawing.Size(123, 43);
            this.btnCC.TabIndex = 5;
            this.btnCC.Text = "C";
            this.btnCC.UseVisualStyleBackColor = true;
            this.btnCC.Click += new System.EventHandler(this.btnC_Click);
            // 
            // btnSin
            // 
            this.btnSin.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnSin.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnSin.Location = new System.Drawing.Point(87, 223);
            this.btnSin.Name = "btnSin";
            this.btnSin.Size = new System.Drawing.Size(87, 39);
            this.btnSin.TabIndex = 6;
            this.btnSin.Text = "sin";
            this.btnSin.UseVisualStyleBackColor = true;
            this.btnSin.Click += new System.EventHandler(this.btnSin_Click);
            // 
            // btnXY
            // 
            this.btnXY.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnXY.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnXY.Location = new System.Drawing.Point(195, 223);
            this.btnXY.Name = "btnXY";
            this.btnXY.Size = new System.Drawing.Size(87, 39);
            this.btnXY.TabIndex = 7;
            this.btnXY.Text = "x^y";
            this.btnXY.UseVisualStyleBackColor = true;
            this.btnXY.Click += new System.EventHandler(this.btnInfixOperator_Click);
            // 
            // btnCos
            // 
            this.btnCos.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnCos.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnCos.Location = new System.Drawing.Point(85, 282);
            this.btnCos.Name = "btnCos";
            this.btnCos.Size = new System.Drawing.Size(87, 39);
            this.btnCos.TabIndex = 8;
            this.btnCos.Text = "cos";
            this.btnCos.UseVisualStyleBackColor = true;
            this.btnCos.Click += new System.EventHandler(this.btnCos_Click);
            // 
            // btnX3
            // 
            this.btnX3.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnX3.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnX3.Location = new System.Drawing.Point(195, 282);
            this.btnX3.Name = "btnX3";
            this.btnX3.Size = new System.Drawing.Size(87, 39);
            this.btnX3.TabIndex = 9;
            this.btnX3.Text = "x*3";
            this.btnX3.UseVisualStyleBackColor = true;
            this.btnX3.Click += new System.EventHandler(this.btnX3_Click);
            // 
            // btnTan
            // 
            this.btnTan.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnTan.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnTan.Location = new System.Drawing.Point(85, 341);
            this.btnTan.Name = "btnTan";
            this.btnTan.Size = new System.Drawing.Size(87, 39);
            this.btnTan.TabIndex = 10;
            this.btnTan.Text = "tan";
            this.btnTan.UseVisualStyleBackColor = true;
            this.btnTan.Click += new System.EventHandler(this.btnTan_Click);
            // 
            // btnX2
            // 
            this.btnX2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnX2.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnX2.Location = new System.Drawing.Point(195, 341);
            this.btnX2.Name = "btnX2";
            this.btnX2.Size = new System.Drawing.Size(87, 39);
            this.btnX2.TabIndex = 11;
            this.btnX2.Text = "x^2";
            this.btnX2.UseVisualStyleBackColor = true;
            this.btnX2.Click += new System.EventHandler(this.btnX2_Click);
            // 
            // btnLog
            // 
            this.btnLog.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnLog.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnLog.Location = new System.Drawing.Point(85, 399);
            this.btnLog.Name = "btnLog";
            this.btnLog.Size = new System.Drawing.Size(87, 39);
            this.btnLog.TabIndex = 12;
            this.btnLog.Text = "log";
            this.btnLog.UseVisualStyleBackColor = true;
            this.btnLog.Click += new System.EventHandler(this.btnLog_Click);
            // 
            // btnNFact
            // 
            this.btnNFact.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnNFact.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnNFact.Location = new System.Drawing.Point(195, 399);
            this.btnNFact.Name = "btnNFact";
            this.btnNFact.Size = new System.Drawing.Size(87, 39);
            this.btnNFact.TabIndex = 13;
            this.btnNFact.Text = "n!";
            this.btnNFact.UseVisualStyleBackColor = true;
            this.btnNFact.Click += new System.EventHandler(this.btnNFact_Click);
            // 
            // btnLn
            // 
            this.btnLn.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnLn.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnLn.Location = new System.Drawing.Point(86, 458);
            this.btnLn.Name = "btnLn";
            this.btnLn.Size = new System.Drawing.Size(87, 39);
            this.btnLn.TabIndex = 14;
            this.btnLn.Text = "In";
            this.btnLn.UseVisualStyleBackColor = true;
            this.btnLn.Click += new System.EventHandler(this.btnLn_Click);
            // 
            // btnXInv
            // 
            this.btnXInv.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnXInv.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnXInv.Location = new System.Drawing.Point(195, 458);
            this.btnXInv.Name = "btnXInv";
            this.btnXInv.Size = new System.Drawing.Size(87, 39);
            this.btnXInv.TabIndex = 15;
            this.btnXInv.Text = "1/x";
            this.btnXInv.UseVisualStyleBackColor = true;
            this.btnXInv.Click += new System.EventHandler(this.btnXInv_Click);
            // 
            // btn7
            // 
            this.btn7.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn7.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn7.Location = new System.Drawing.Point(314, 223);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(64, 39);
            this.btn7.TabIndex = 16;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.btnn_Click);
            // 
            // btn8
            // 
            this.btn8.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn8.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn8.Location = new System.Drawing.Point(385, 223);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(64, 39);
            this.btn8.TabIndex = 17;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.btnn_Click);
            // 
            // btn9
            // 
            this.btn9.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn9.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn9.Location = new System.Drawing.Point(456, 223);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(64, 39);
            this.btn9.TabIndex = 18;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.btnn_Click);
            // 
            // button17
            // 
            this.button17.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button17.ForeColor = System.Drawing.Color.Red;
            this.button17.Location = new System.Drawing.Point(527, 223);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(64, 39);
            this.button17.TabIndex = 19;
            this.button17.Text = "/";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.btnInfixOperator_Click);
            // 
            // button18
            // 
            this.button18.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button18.ForeColor = System.Drawing.Color.Red;
            this.button18.Location = new System.Drawing.Point(598, 223);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(64, 39);
            this.button18.TabIndex = 20;
            this.button18.Text = "Mod";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.btnInfixOperator_Click);
            // 
            // button19
            // 
            this.button19.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button19.ForeColor = System.Drawing.Color.Red;
            this.button19.Location = new System.Drawing.Point(674, 223);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(64, 39);
            this.button19.TabIndex = 21;
            this.button19.Text = "And";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.btnInfixOperator_Click);
            // 
            // button20
            // 
            this.button20.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button20.ForeColor = System.Drawing.Color.Red;
            this.button20.Location = new System.Drawing.Point(674, 282);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(64, 39);
            this.button20.TabIndex = 27;
            this.button20.Text = "Xor";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.btnInfixOperator_Click);
            // 
            // button21
            // 
            this.button21.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button21.ForeColor = System.Drawing.Color.Red;
            this.button21.Location = new System.Drawing.Point(598, 282);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(64, 39);
            this.button21.TabIndex = 26;
            this.button21.Text = "Or";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.btnInfixOperator_Click);
            // 
            // button22
            // 
            this.button22.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button22.ForeColor = System.Drawing.Color.Red;
            this.button22.Location = new System.Drawing.Point(527, 282);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(64, 39);
            this.button22.TabIndex = 25;
            this.button22.Text = "*";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.btnInfixOperator_Click);
            // 
            // btn6
            // 
            this.btn6.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn6.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn6.Location = new System.Drawing.Point(456, 282);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(64, 39);
            this.btn6.TabIndex = 24;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.btnn_Click);
            // 
            // btn5
            // 
            this.btn5.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn5.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn5.Location = new System.Drawing.Point(385, 282);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(64, 39);
            this.btn5.TabIndex = 23;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.btnn_Click);
            // 
            // btn4
            // 
            this.btn4.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn4.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn4.Location = new System.Drawing.Point(314, 282);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(64, 39);
            this.btn4.TabIndex = 22;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.btnn_Click);
            // 
            // btnNot
            // 
            this.btnNot.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnNot.ForeColor = System.Drawing.Color.Red;
            this.btnNot.Location = new System.Drawing.Point(674, 341);
            this.btnNot.Name = "btnNot";
            this.btnNot.Size = new System.Drawing.Size(64, 39);
            this.btnNot.TabIndex = 33;
            this.btnNot.Text = "Not";
            this.btnNot.UseVisualStyleBackColor = true;
            this.btnNot.Click += new System.EventHandler(this.btnNot_Click);
            // 
            // button27
            // 
            this.button27.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button27.ForeColor = System.Drawing.Color.Red;
            this.button27.Location = new System.Drawing.Point(598, 341);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(64, 39);
            this.button27.TabIndex = 32;
            this.button27.Text = "Lsh";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.btnInfixOperator_Click);
            // 
            // button28
            // 
            this.button28.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button28.ForeColor = System.Drawing.Color.Red;
            this.button28.Location = new System.Drawing.Point(527, 341);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(64, 39);
            this.button28.TabIndex = 31;
            this.button28.Text = "-";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.btnInfixOperator_Click);
            // 
            // btn3
            // 
            this.btn3.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn3.Location = new System.Drawing.Point(456, 341);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(64, 39);
            this.btn3.TabIndex = 30;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.btnn_Click);
            // 
            // btn2
            // 
            this.btn2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn2.Location = new System.Drawing.Point(385, 341);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(64, 39);
            this.btn2.TabIndex = 29;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btnn_Click);
            // 
            // btn1
            // 
            this.btn1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn1.Location = new System.Drawing.Point(314, 341);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(64, 39);
            this.btn1.TabIndex = 28;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btnn_Click);
            // 
            // btnInt
            // 
            this.btnInt.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnInt.ForeColor = System.Drawing.Color.Red;
            this.btnInt.Location = new System.Drawing.Point(674, 399);
            this.btnInt.Name = "btnInt";
            this.btnInt.Size = new System.Drawing.Size(64, 39);
            this.btnInt.TabIndex = 39;
            this.btnInt.Text = "Int";
            this.btnInt.UseVisualStyleBackColor = true;
            this.btnInt.Click += new System.EventHandler(this.btnInt_Click);
            // 
            // btnResult
            // 
            this.btnResult.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnResult.ForeColor = System.Drawing.Color.Red;
            this.btnResult.Location = new System.Drawing.Point(598, 399);
            this.btnResult.Name = "btnResult";
            this.btnResult.Size = new System.Drawing.Size(64, 39);
            this.btnResult.TabIndex = 38;
            this.btnResult.Text = "=";
            this.btnResult.UseVisualStyleBackColor = true;
            this.btnResult.Click += new System.EventHandler(this.btnResult_Click);
            // 
            // button34
            // 
            this.button34.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button34.ForeColor = System.Drawing.Color.Red;
            this.button34.Location = new System.Drawing.Point(527, 399);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(64, 39);
            this.button34.TabIndex = 37;
            this.button34.Text = "+";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.btnInfixOperator_Click);
            // 
            // btnPoint
            // 
            this.btnPoint.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnPoint.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnPoint.Location = new System.Drawing.Point(456, 399);
            this.btnPoint.Name = "btnPoint";
            this.btnPoint.Size = new System.Drawing.Size(64, 39);
            this.btnPoint.TabIndex = 36;
            this.btnPoint.Text = ".";
            this.btnPoint.UseVisualStyleBackColor = true;
            this.btnPoint.Click += new System.EventHandler(this.btnPoint_Click);
            // 
            // btnSign
            // 
            this.btnSign.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnSign.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnSign.Location = new System.Drawing.Point(385, 399);
            this.btnSign.Name = "btnSign";
            this.btnSign.Size = new System.Drawing.Size(64, 39);
            this.btnSign.TabIndex = 35;
            this.btnSign.Text = "+/-";
            this.btnSign.UseVisualStyleBackColor = true;
            this.btnSign.Click += new System.EventHandler(this.btnSign_Click);
            // 
            // btn0
            // 
            this.btn0.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn0.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn0.Location = new System.Drawing.Point(314, 399);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(64, 39);
            this.btn0.TabIndex = 34;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = true;
            this.btn0.Click += new System.EventHandler(this.btnn_Click);
            // 
            // btnF
            // 
            this.btnF.Enabled = false;
            this.btnF.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnF.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnF.Location = new System.Drawing.Point(674, 458);
            this.btnF.Name = "btnF";
            this.btnF.Size = new System.Drawing.Size(64, 39);
            this.btnF.TabIndex = 45;
            this.btnF.Text = "F";
            this.btnF.UseVisualStyleBackColor = true;
            this.btnF.Click += new System.EventHandler(this.btnn_Click);
            // 
            // btnE
            // 
            this.btnE.Enabled = false;
            this.btnE.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnE.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnE.Location = new System.Drawing.Point(598, 458);
            this.btnE.Name = "btnE";
            this.btnE.Size = new System.Drawing.Size(64, 39);
            this.btnE.TabIndex = 44;
            this.btnE.Text = "E";
            this.btnE.UseVisualStyleBackColor = true;
            this.btnE.Click += new System.EventHandler(this.btnn_Click);
            // 
            // btnD
            // 
            this.btnD.Enabled = false;
            this.btnD.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnD.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnD.Location = new System.Drawing.Point(527, 458);
            this.btnD.Name = "btnD";
            this.btnD.Size = new System.Drawing.Size(64, 39);
            this.btnD.TabIndex = 43;
            this.btnD.Text = "D";
            this.btnD.UseVisualStyleBackColor = true;
            this.btnD.Click += new System.EventHandler(this.btnn_Click);
            // 
            // btnB
            // 
            this.btnB.Enabled = false;
            this.btnB.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnB.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnB.Location = new System.Drawing.Point(385, 458);
            this.btnB.Name = "btnB";
            this.btnB.Size = new System.Drawing.Size(64, 39);
            this.btnB.TabIndex = 41;
            this.btnB.Text = "B";
            this.btnB.UseVisualStyleBackColor = true;
            this.btnB.Click += new System.EventHandler(this.btnn_Click);
            // 
            // btnA
            // 
            this.btnA.Enabled = false;
            this.btnA.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnA.Location = new System.Drawing.Point(314, 458);
            this.btnA.Name = "btnA";
            this.btnA.Size = new System.Drawing.Size(64, 39);
            this.btnA.TabIndex = 40;
            this.btnA.Text = "A";
            this.btnA.UseVisualStyleBackColor = true;
            this.btnA.Click += new System.EventHandler(this.btnn_Click);
            // 
            // btnC
            // 
            this.btnC.Enabled = false;
            this.btnC.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnC.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnC.Location = new System.Drawing.Point(456, 458);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(64, 39);
            this.btnC.TabIndex = 46;
            this.btnC.Text = "C";
            this.btnC.UseVisualStyleBackColor = true;
            this.btnC.Click += new System.EventHandler(this.btnn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(914, 545);
            this.Controls.Add(this.btnC);
            this.Controls.Add(this.btnF);
            this.Controls.Add(this.btnE);
            this.Controls.Add(this.btnD);
            this.Controls.Add(this.btnB);
            this.Controls.Add(this.btnA);
            this.Controls.Add(this.btnInt);
            this.Controls.Add(this.btnResult);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.btnPoint);
            this.Controls.Add(this.btnSign);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.btnNot);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btnXInv);
            this.Controls.Add(this.btnLn);
            this.Controls.Add(this.btnNFact);
            this.Controls.Add(this.btnLog);
            this.Controls.Add(this.btnX2);
            this.Controls.Add(this.btnTan);
            this.Controls.Add(this.btnX3);
            this.Controls.Add(this.btnCos);
            this.Controls.Add(this.btnXY);
            this.Controls.Add(this.btnSin);
            this.Controls.Add(this.btnCC);
            this.Controls.Add(this.btnCE);
            this.Controls.Add(this.btnBS);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblResult);
            this.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Name = "Form1";
            this.Text = "공학용계산기";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton btnBin;
        private System.Windows.Forms.RadioButton btnOct;
        private System.Windows.Forms.RadioButton rdoDec;
        private System.Windows.Forms.RadioButton btnHex;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton rdoModeDeg;
        private System.Windows.Forms.Button btnBS;
        private System.Windows.Forms.Button btnCE;
        private System.Windows.Forms.Button btnCC;
        private System.Windows.Forms.Button btnSin;
        private System.Windows.Forms.Button btnXY;
        private System.Windows.Forms.Button btnCos;
        private System.Windows.Forms.Button btnX3;
        private System.Windows.Forms.Button btnTan;
        private System.Windows.Forms.Button btnX2;
        private System.Windows.Forms.Button btnLog;
        private System.Windows.Forms.Button btnNFact;
        private System.Windows.Forms.Button btnLn;
        private System.Windows.Forms.Button btnXInv;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btnNot;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btnInt;
        private System.Windows.Forms.Button btnResult;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button btnPoint;
        private System.Windows.Forms.Button btnSign;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btnF;
        private System.Windows.Forms.Button btnE;
        private System.Windows.Forms.Button btnD;
        private System.Windows.Forms.Button btnB;
        private System.Windows.Forms.Button btnA;
        private System.Windows.Forms.CheckBox chkInv;
        private System.Windows.Forms.Button btnC;
    }
}

