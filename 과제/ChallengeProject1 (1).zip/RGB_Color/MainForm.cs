﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RGB_Color
{
    public partial class MainForm: Form
    {
        public MainForm()
        {
            InitializeComponent();
        }


        private void hsbRed_Scroll(object sender, ScrollEventArgs e)
        {
            lblRedPanel.BackColor = Color.FromArgb(hsbRed.Value, 0, 0);
            lblResultPanel.BackColor = Color.FromArgb(hsbRed.Value, hsbGreen.Value, hsbBlue.Value);
            lblResultPanel.ForeColor = Color.FromArgb(~lblResultPanel.BackColor.ToArgb());
            lblRed.Text = hsbRed.Value.ToString();

        }

        private void hsbGreen_Scroll(object sender, ScrollEventArgs e)
        {
            lblGreenPanel.BackColor = Color.FromArgb(hsbGreen.Value, 0, 0);
            lblResultPanel.BackColor = Color.FromArgb(hsbGreen.Value, hsbGreen.Value, hsbBlue.Value);
            lblResultPanel.ForeColor = Color.FromArgb(~lblResultPanel.BackColor.ToArgb());
            lblGreen.Text = hsbGreen.Value.ToString();
        }

        private void hsbBlue_Scroll(object sender, ScrollEventArgs e)
        {
            lblBluePanel.BackColor = Color.FromArgb(hsbBlue.Value, 0, 0);
            lblResultPanel.BackColor = Color.FromArgb(hsbRed.Value, hsbGreen.Value, hsbBlue.Value);
            lblResultPanel.ForeColor = Color.FromArgb(~lblResultPanel.BackColor.ToArgb());
            lblBlue.Text = hsbBlue.Value.ToString();
        }
    }
}
