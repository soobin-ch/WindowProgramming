﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookRentalSystem_CSB
{
    public partial class BookRentalForm: Form
    {

        DataSet myDs;

        private int curCustomId = 0;
        private int curBookId = 0;

        public BookRentalForm()
        {
            InitializeComponent();
        }

        private void tabControl1_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab == tabCustomers)
            {
                // tabCustomers 선택 시 실행될 코드
            }
            else if (tabControl1.SelectedTab == tabRent)
            {
                // tabRent 선택 시 실행될 코드
            }
            else if (tabControl1.SelectedTab == tabReturn)
            {
                // tabReturn 선택 시 실행될 코드
            }
            else if (tabControl1.SelectedTab == tabBooks)
            {
                // tabBooks 선택 시 실행될 코드
            }
            else
            {
                // 그 외의 탭 선택 시 실행될 코드
            }
        }
    }
}
