﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookRentalSystem_CSB
{
    namespace BookRentalSystem
    {
        class DbManager
        {
            // 데이터 소스 지정
            string dbSrc = "Data Source=(local)\\WWSQLEXPRESS; " +
                           "User Id=BrProgrammer25; Password=pass; " +
                           "Initial Catalog=dbBookRental25";

            // SqlConnection 및 SqlCommand 객체 선언
            SqlConnection myConn;
            SqlCommand myComm;

            // DB 연결 지정
            public void Open()
            {
                myConn = new SqlConnection(dbSrc);
                myConn.Open();
            }

            // DB 연결 해제
            public void Close()
            {
                myConn.Close();
            }

            // 결과 없는 쿼리문 실행
            public void ExcuteSql(string myQuery)
            {
                myComm = new SqlCommand(myQuery, myConn);
                myComm.ExecuteNonQuery();
            }

            // SqlDataReader 형식의 결과 반환 (하나의 레코드)
            public SqlDataReader ExecuteReader(string myQuery)
            {
                myComm = new SqlCommand(myQuery, myConn);
                return myComm.ExecuteReader();
            }

            // DataSet 형식의 결과 반환 (여러 개의 레코드)
            public DataSet GetDataSet(string myQuery, string myTable)
            {
                // SqlDataAdapter 객체를 만들고,
                // 실행하여 결과를 DataSet에 전달
                SqlDataAdapter myAdapter = new SqlDataAdapter(myQuery, myConn);
                DataSet myDs = new DataSet(myTable);
                myAdapter.Fill(myDs, myTable);
                return myDs;
            }

        }
    }

}
